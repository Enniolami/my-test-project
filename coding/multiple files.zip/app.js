let age = prompt("how old are you?");
if (age >= 16) {
    alert ("Welcome to Ennies beauty home");
} else {
    alert("You are not old enough to use makeup");
}